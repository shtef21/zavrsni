
import src.trainer as trainer

# trainer.train_all_adam()
trainer.train_best_sgd_sched()
